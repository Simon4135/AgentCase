# 输出骨架与渲染脚本

## 文件清单

- `历史采购价曲线数据.xlsx` —— 正式件本体 · 37 条清洗记录 + 月度价格轨迹 + 调价节点 + 量价并排
- `谈判底稿（曲线版）.xlsx` —— 曲线上能说的话 · 每句对应数据出处
- `数据质量待确认清单.xlsx` —— 3 条疑似录入错误的核对路径

## sheet 结构

1. `结论摘要` —— 本次结论 / 关键指标 / 输入依据 / 人工边界 / 签批栏
2. `1.涨幅计算` —— 列头：口径 | 涨幅 | 备注
3. `2.谈判底稿` —— 列头：谈判语句 | 数据出处

## 视觉规范

正式件本体用**风格 A**（浅灰表头 `F6F8FB` + 深字 `1A2332`）；
清单类用**风格 B**（蓝底白字 `2D6CDF`）。同一个包里不要混用。

```python
INK, MUTED, GREY = "1A2332", "5A6675", "8A94A3"
HEAD_A, HEAD_B   = "F6F8FB", "2D6CDF"
RED, AMBER, GREEN = "C62F2F", "B9770A", "1E8E5A"
FONT = "微软雅黑"
```

必做三件事：

```python
ws.freeze_panes = "A4"                          # 冻结表头
ws.auto_filter.ref = f"A3:{last_col}{last_row}"   # 开筛选
ws.sheet_view.showGridLines = False              # 关网格线，更像正式件
```

## 签批栏（正式件必备）

编制 / 审核 / 会签 / 批准四栏 + 日期列。
**推荐意见、完成质量、责任认定三栏留空。**

## 渲染脚本自检

```python
# 分项加总必须等于合计
assert abs(sum(items) - total) < 0.01, f"分项 {sum(items)} != 合计 {total}"
# 占比合计必须等于 100%
assert abs(sum(pcts) - 100) < 0.1
# 行数守恒
assert len(out_rows) == len(in_rows), "行数不守恒"
```

跑不过就不出文件 —— 从根上杜绝「合计对不上」这种一眼被看穿的错。
